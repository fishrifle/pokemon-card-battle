# Pokemon Card Battle Arena

A Next.js 15 (App Router) + React 19 + TypeScript + Tailwind CSS 4 single-page Pokemon card battle game. Client-side only (no backend); all state lives in React and `localStorage`.

## Scripts

```bash
npm run dev      # next dev --turbopack (http://localhost:3000)
npm run build    # next build
npm run start    # next start
npm run lint     # next lint
```

## Project layout

- `src/app/page.tsx` — Home: card grid, search/type/rarity filters, 2-card selection, first-run tutorial modal. Navigates to `/battle` with selected cards stashed in `localStorage`.
- `src/app/battle/page.tsx` — Battle screen. Reads `battleCards` from `localStorage`, runs turn-based dice combat, persists win/loss to `pokemonStats`. Contains the local `Dice` and `PlayerCard` components plus all battle animations/CSS.
- `src/app/layout.tsx` — Root layout, Geist fonts, `suppressHydrationWarning` on body.
- `src/app/globals.css` — Global styles and keyframes (additional keyframes are also inlined via `<style jsx>` in `battle/page.tsx`).
- `src/components/PokemonCard.tsx` — Card used in the selection grid. Single-click select, double-click flip to show wins/losses.
- `src/components/ParticleEffect.tsx` — Type-themed particle overlay (fire/water/electric/grass/psychic/impact).
- `src/data/pokemonData.ts` — Builds the 300-card roster from gen1/gen2 databases on each call (`getPokemonCards()`), merging persisted stats from `localStorage`. Also exports a pre-built `pokemonCards` constant (beware: runs at import; `window` guard is in `loadPokemonStats`).
- `src/data/gen1PokemonDatabase.ts` / `gen2PokemonDatabase.ts` — Static Pokemon data (name, types, hp/attack/defense, signature move).
- `src/hooks/useSound.ts` — Web Audio API–based procedural sound effects (attack, critical, victory, defeat, background). No audio files shipped.
- `src/types/pokemon.ts` — `PokemonCard`, `PokemonMove`, `BattleState` types. `types: string[]` supports dual-types.

## Key conventions & gotchas

- **Path alias**: `@/*` → `src/*` (see `tsconfig.json`).
- **Client components**: Both pages are `'use client'`. There is no server data fetching.
- **Persistence keys** in `localStorage`:
  - `battleCards` — the two cards selected for the current battle (JSON array).
  - `pokemonStats` — `{ [cardId]: { wins, losses } }`.
  - `hasSeenTutorial` — flag to suppress the home-page tutorial modal.
- **Card IDs**: Assigned sequentially at generation time (1..300) in `pokemonData.ts`, NOT the Pokedex number. The sprite URL maps back to the real dex number (`pokemon.id` for gen1; `pokemon.id <= 151 ? id : id + 100` for gen2 to skip gen1 sprites 152–251 offset).
- **Rarity** is derived from stat totals in `getRarityByStats` (common <120, uncommon ≥120, rare ≥200, legendary ≥300). Don't hand-assign rarity on new Pokemon — just give them stats.
- **Images**: Remote sprites from `raw.githubusercontent.com/PokeAPI/sprites/...`. `next.config.ts` whitelists that host — don't break that pattern if adding new image sources.
- **Battle damage formula** (in `battle/page.tsx` `processBattle`):
  - `base = floor(specialMove.damage * 0.2)`
  - `bonus = atkRoll*5 - defRoll*3`
  - multiply by type effectiveness (1.25 / 0.8 / 1.0 via `getTypeEffectiveness`)
  - crit (atkRoll === 6) multiplies by 1.5
  - final damage is clamped to `[15%, 50%]` of defender's maxHp
  - The README's prose description of damage is outdated relative to the code — trust the code.
- **Type effectiveness** map is inline in `battle/page.tsx`; it only covers attacker-advantage relations (reverse lookup gives 0.8). Not a full type chart.
- **Animations**: Keyframes are split between `globals.css` and inline `<style jsx>` blocks in the battle page. If you add/modify an animation, check both places to avoid duplicates.
- **Turbopack**: Dev server uses `--turbopack`. The `next.config.ts` defines a turbopack SVG loader rule using `@svgr/webpack` — note that package is NOT in `package.json` dependencies, so actually importing an SVG as a component will fail until it's installed.

## Adding a Pokemon

Append to `gen1Pokemon` or `gen2Pokemon` in the corresponding database file. Provide `id` (dex number), `name`, `types`, `hp`, `attack`, `defense`, `signatureMove`. Rarity auto-derives; card id auto-assigns.

## Known rough edges

- `pokemonData.ts` exports both a function (`getPokemonCards`) and a snapshot (`pokemonCards`) built at import time. The SSR-unsafe `localStorage` read is guarded, but the eager export still runs on import — prefer `getPokemonCards()` inside `useEffect`, which is what `page.tsx` does.
- `battle/page.tsx` has a `useEffect` with dep array `[winner, battlePhase, battleCards]` but the lint config (`eslint-config-next`) may flag missing deps elsewhere — run `npm run lint` after non-trivial changes.
